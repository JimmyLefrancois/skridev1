const socket = io();
const canvas = document.getElementById('drawing-board');
const ctx = canvas.getContext('2d');
const guessInput = document.getElementById('guess-input');
const chatMessages = document.getElementById('chat-messages');
const colorPicker = document.createElement('input');
colorPicker.type = 'color';
const playersList = document.getElementById('players');
const timerDisplay = document.getElementById('timer');

let isDrawing = false;
let currentColor = '#000000';
let currentSize = 5;
let isDrawingAllowed = false;
let drawingHistory = [];
let currentRoom = null;
let username = null;
let currentWord = '';
let revealedIndices = new Set();

function initializeGame() {
    const loginScreen = document.getElementById('login-screen');
    const gameContainer = document.getElementById('game-container');
    const joinBtn = document.getElementById('join-btn');

    joinBtn.addEventListener('click', () => {
        username = document.getElementById('username-input').value.trim();
        const roomId = document.getElementById('room-input').value.trim() || 'default';
        
        if (username) {
            currentRoom = roomId;
            socket.emit('join-room', roomId, username);
            loginScreen.style.display = 'none';
            gameContainer.style.display = 'flex';
            setupGame();
        }
    });
}

function setupGame() {
    setupColorPicker();
    setupCanvas();
    setupEventListeners();
}

function setupColorPicker() {
    const colors = ['#000000', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];
    const colorsDiv = document.querySelector('.colors');
    colors.forEach(color => {
        const colorBtn = document.createElement('button');
        colorBtn.style.backgroundColor = color;
        colorBtn.onclick = () => setColor(color);
        colorsDiv.appendChild(colorBtn);
    });
}

function setupCanvas() {
    resizeCanvas();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
}

function setupEventListeners() {
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);
    window.addEventListener('resize', resizeCanvas);

    document.getElementById('clear-btn').addEventListener('click', () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        socket.emit('clear-canvas', { roomId: currentRoom });
    });

    guessInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const message = guessInput.value.trim();
            if (message) {
                socket.emit('guess', {
                    guess: message,
                    roomId: currentRoom
                });
                guessInput.value = '';
            }
        }
    });
}

function resizeCanvas() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
}

function setColor(color) {
    currentColor = color;
    ctx.strokeStyle = color;
}

function startDrawing(e) {
    if (!isDrawingAllowed) return;
    isDrawing = true;
    const point = getCanvasPoint(e);
    ctx.beginPath();
    ctx.moveTo(point.x, point.y);
    emitDrawing({
        ...point,
        type: 'start'
    });
}

function draw(e) {
    if (!isDrawing || !isDrawingAllowed) return;
    
    const point = getCanvasPoint(e);
    drawLine(point);
    emitDrawing({
        ...point,
        type: 'draw'
    });
}

function drawLine(point) {
    ctx.lineWidth = currentSize;
    ctx.lineTo(point.x, point.y);
    ctx.stroke();
}

function getCanvasPoint(e) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
    };
}

function emitDrawing(point) {
    socket.emit('draw', {
        ...point,
        color: currentColor,
        size: currentSize,
        roomId: currentRoom
    });
}

function stopDrawing() {
    isDrawing = false;
    ctx.beginPath();
}

// Socket event handlers
socket.on('draw', (data) => {
    ctx.strokeStyle = data.color;
    ctx.lineWidth = data.size;
    
    if (data.type === 'start') {
        ctx.beginPath();
        ctx.moveTo(data.x, data.y);
    } else if (data.type === 'draw') {
        ctx.lineTo(data.x, data.y);
        ctx.stroke();
    }
});

socket.on('player-joined', (players) => {
    updatePlayersList(players);
});

socket.on('chat-message', (data) => {
    const message = document.createElement('div');
    message.className = 'chat-message';
    
    switch(data.type) {
        case 'correct':
            message.className += ' correct-guess';
            break;
        case 'guess':
            message.className += ' guess-message';
            break;
        case 'message':
            message.className += ' normal-message';
            break;
    }

    message.innerHTML = `<span class="player-name">${data.username}</span>: ${data.message}`;
    chatMessages.appendChild(message);
    chatMessages.scrollTop = chatMessages.scrollHeight;
});

// Simplifier l'événement correct-guess puisque le message est déjà affiché
socket.on('correct-guess', (data) => {
    if (data.scores) {
        updatePlayersList(data.scores);
    }
});

socket.on('game-state-update', (state) => {
    isDrawingAllowed = state.isDrawer;
    currentWord = state.word;
    revealedIndices = new Set(); // Réinitialiser les indices
    updateWordDisplay();
});

socket.on('hint-update', (data) => {
    if (!isDrawingAllowed) {
        revealedIndices.add(data.index);
        currentWord = data.word;
        
        const message = document.createElement('div');
        message.className = 'chat-message hint-message';
        message.textContent = `Indice ${data.revealedIndices.length}/${data.maxHints} : La lettre "${data.letter}" a été révélée !`;
        if (data.remainingHints === 0) {
            message.textContent += " (Dernier indice)";
        }
        chatMessages.appendChild(message);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        updateWordDisplay();
    }
});

function updateWordDisplay() {
    const wordDisplay = document.getElementById('word-display');
    if (isDrawingAllowed) {
        wordDisplay.textContent = `Mot à dessiner: ${currentWord}`;
    } else {
        // Créer le mot masqué avec les indices révélés
        const hiddenWord = [...currentWord].map((letter, i) => 
            revealedIndices.has(i) ? letter : '_'
        ).join(' '); // Ajouter des espaces entre les lettres pour plus de lisibilité
        wordDisplay.textContent = `Mot: ${hiddenWord}`;
    }
}

socket.on('clear-canvas', () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
});

function updatePlayersList(players) {
    playersList.innerHTML = '';
    players.forEach(player => {
        const li = document.createElement('li');
        li.className = 'player-item';
        if (player.id === socket.id) {
            li.className += ' current-player';
        }
        li.innerHTML = `
            <span class="player-name">${player.username}</span>
            <span class="player-score">${player.score || 0}</span>
        `;
        playersList.appendChild(li);
    });
}

socket.on('word-choices', (words) => {
    // Créer un overlay pour choisir le mot
    const overlay = document.createElement('div');
    overlay.className = 'word-choice-overlay';
    overlay.innerHTML = `
        <div class="word-choice-container">
            <h3>Choisissez un mot à dessiner</h3>
            <div class="word-buttons">
                ${words.map(word => `
                    <button class="word-choice-btn">${word}</button>
                `).join('')}
            </div>
        </div>
    `;
    document.body.appendChild(overlay);

    // Gérer la sélection du mot
    overlay.querySelectorAll('.word-choice-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            socket.emit('select-word', {
                word: btn.textContent,
                roomId: currentRoom
            });
            overlay.remove();
        });
    });
});

socket.on('waiting-for-word', (data) => {
    const wordDisplay = document.getElementById('word-display');
    wordDisplay.textContent = `${data.drawerUsername} est en train de choisir un mot...`;
});

socket.on('timer-update', (timeLeft) => {
    timerDisplay.textContent = `Temps: ${timeLeft}s`;
});

initializeGame();
