const { pool } = require('../db/mysql');

class Player {
    static async findOne(username) {
        const [rows] = await pool.execute(
            'SELECT * FROM players WHERE username = ?',
            [username]
        );
        return rows[0];
    }

    static async create(username) {
        const [result] = await pool.execute(
            'INSERT INTO players (username) VALUES (?)',
            [username]
        );
        return { id: result.insertId, username };
    }

    static async updateScore(id, score, isWinner) {
        await pool.execute(
            `UPDATE players 
             SET totalScore = totalScore + ?,
                 gamesPlayed = gamesPlayed + 1,
                 wins = wins + ?,
                 lastPlayed = CURRENT_TIMESTAMP
             WHERE id = ?`,
            [score, isWinner ? 1 : 0, id]
        );
    }
}

module.exports = Player;
