require('dotenv').config();
const express = require('express');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const { initDB } = require('./db/mysql');
const Player = require('./models/Player');
const path = require('path');

// Configure static files middleware
app.use(express.static(path.join(__dirname, 'public')));

// Add root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Initialiser MySQL
initDB();

const ROUND_TIME = 80; // seconds
const MIN_PLAYERS = 1;
const words = require('./words.json');

class GameRoom {
    constructor(id) {
        this.id = id;
        this.players = [];
        this.currentDrawer = null;
        this.word = null;
        this.timer = null;
        this.round = 0;
        this.maxRounds = 3;
        this.state = 'waiting'; // waiting, playing, finished
        this.guessedPlayers = new Set();
        this.revealedIndices = new Set();
        this.hintTimer = null;
        this.wordChoices = [];
        this.timeLeft = ROUND_TIME;
    }

    addPlayer(player) {
        this.players.push(player);
        if (this.players.length >= MIN_PLAYERS && this.state === 'waiting') {
            this.startGame();
        }
    }

    removePlayer(playerId) {
        this.players = this.players.filter(p => p.id !== playerId);
        if (this.players.length < MIN_PLAYERS) {
            this.endGame();
        }
    }

    startGame() {
        this.state = 'playing';
        this.round = 0;
        this.startRound();
    }

    startRound() {
        this.round++;
        if (this.round > this.maxRounds) {
            return this.endGame();
        }

        this.guessedPlayers.clear();
        this.revealedIndices.clear();
        const nextDrawerIndex = this.round % this.players.length;
        this.currentDrawer = this.players[nextDrawerIndex];
        
        // Générer 3 mots au choix
        this.wordChoices = Array(3).fill().map(() => this.getRandomWord());
        
        // Envoyer les choix au dessinateur
        io.to(this.currentDrawer.id).emit('word-choices', this.wordChoices);
        
        // Informer les autres joueurs qu'un nouveau dessinateur choisit son mot
        io.to(this.id).emit('waiting-for-word', {
            drawerUsername: this.currentDrawer.username
        });
    }

    getRandomWord() {
        const categories = Object.keys(words);
        const randomCategory = categories[Math.floor(Math.random() * categories.length)];
        const wordList = words[randomCategory];
        return wordList[Math.floor(Math.random() * wordList.length)];
    }

    resetTimer() {
        if (this.timer) clearTimeout(this.timer);
        this.timeLeft = ROUND_TIME;
        this.timer = setInterval(() => {
            this.timeLeft--;
            io.to(this.id).emit('timer-update', this.timeLeft);
            
            if (this.timeLeft <= 0) this.endRound();
        }, 1000);
    }

    startHintTimer() {
        if (this.hintTimer) clearInterval(this.hintTimer);
        
        this.hintTimer = setInterval(() => {
            if (this.word) {
                const availableIndices = [...this.word].map((_, i) => i)
                    .filter(i => !this.revealedIndices.has(i));

                if (availableIndices.length > 0) {
                    const randomIndex = availableIndices[Math.floor(Math.random() * availableIndices.length)];
                    this.revealedIndices.add(randomIndex);
                    
                    io.to(this.id).emit('hint-update', {
                        index: randomIndex,
                        letter: this.word[randomIndex],
                        revealedIndices: Array.from(this.revealedIndices)
                    });
                }
            }
        }, 15000); // 15 secondes
    }

    endRound() {
        clearTimeout(this.timer);
        if (this.hintTimer) clearInterval(this.hintTimer);
        // Calculate scores
        this.startRound();
    }

    endGame() {
        this.state = 'finished';
        clearTimeout(this.timer);
        if (this.hintTimer) clearInterval(this.hintTimer);
        // Announce winner
    }

    handleGuess(playerId, guess) {
        if (this.word === guess.toLowerCase() && !this.guessedPlayers.has(playerId)) {
            this.guessedPlayers.add(playerId);
            const player = this.players.find(p => p.id === playerId);
            if (player) {
                player.score += Math.floor(this.timeLeft * 0.5);
            }
            
            if (this.guessedPlayers.size === this.players.length - 1) {
                this.endRound();
            }
            return true;
        }
        return false;
    }

    getWordWithHints(isDrawer) {
        if (isDrawer) return this.word;
        return [...this.word].map((letter, i) => 
            this.revealedIndices.has(i) ? letter : '_'
        ).join('');
    }

    selectWord(word) {
        if (!this.wordChoices.includes(word)) return;
        this.word = word.toLowerCase();
        this.resetTimer();
        this.startHintTimer();
        
        // Envoyer l'état complet au dessinateur
        io.to(this.currentDrawer.id).emit('game-state-update', {
            currentDrawer: this.currentDrawer,
            word: this.word,
            round: this.round,
            maxRounds: this.maxRounds,
            timeLeft: this.timeLeft,
            isDrawer: true
        });

        // Envoyer l'état masqué aux autres joueurs (utiliser io au lieu de socket)
        io.to(this.id).emit('game-state-update', {
            currentDrawer: this.currentDrawer,
            word: this.getWordWithHints(false),
            round: this.round,
            maxRounds: this.maxRounds,
            timeLeft: this.timeLeft,
            isDrawer: false
        });
    }
}

const rooms = new Map();

io.on('connection', (socket) => {
    console.log('User connected');

    socket.on('join-room', async (roomId, username) => {
        try {
            let player = await Player.findOne(username);
            if (!player) {
                player = await Player.create(username);
            }

            socket.join(roomId);
            if (!rooms.has(roomId)) {
                rooms.set(roomId, new GameRoom(roomId));
            }
            const room = rooms.get(roomId);
            room.addPlayer({ 
                id: socket.id, 
                username, 
                score: 0,
                dbId: player.id 
            });
            io.to(roomId).emit('player-joined', room.players);
        } catch (error) {
            console.error('Error joining room:', error);
            socket.emit('error', 'Unable to join room');
        }
    });

    socket.on('draw', (data) => {
        const room = rooms.get(data.roomId);
        if (room && room.currentDrawer?.id === socket.id) {
            socket.broadcast.to(data.roomId).emit('draw', data);
        }
    });

    socket.on('clear-canvas', (data) => {
        const room = rooms.get(data.roomId);
        if (room && room.currentDrawer?.id === socket.id) {
            socket.broadcast.to(data.roomId).emit('clear-canvas');
        }
    });

    socket.on('guess', (data) => {
        const room = rooms.get(data.roomId);
        if (!room) return;

        const player = room.players.find(p => p.id === socket.id);
        if (!player) return;

        // Si c'est le dessinateur, traiter comme un message normal
        if (room.currentDrawer?.id === socket.id) {
            io.to(data.roomId).emit('chat-message', {
                username: player.username,
                message: data.guess,
                type: 'message'
            });
            return;
        }

        const guess = data.guess.toLowerCase().trim();

        // Envoyer le message à tout le monde
        io.to(data.roomId).emit('chat-message', {
            username: player.username,
            message: data.guess,
            type: room.word === guess ? 'correct' : 'guess'
        });

        // Si c'est la bonne réponse
        if (room.word === guess && !room.guessedPlayers.has(socket.id)) {
            room.handleGuess(socket.id, guess);
            io.to(data.roomId).emit('correct-guess', {
                player: socket.id,
                playerName: player.username,
                scores: room.players.map(p => ({
                    id: p.id,
                    username: p.username,
                    score: p.score
                }))
            });
        }
    });

    // Ajouter un gestionnaire pour les messages normaux
    socket.on('chat-message', (data) => {
        const room = rooms.get(data.roomId);
        if (!room) return;

        const player = room.players.find(p => p.id === socket.id);
        if (!player) return;

        io.to(data.roomId).emit('chat-message', {
            username: player.username,
            message: data.message,
            type: 'message'
        });
    });

    // Ajouter gestion des scores
    socket.on('game-ended', async (data) => {
        try {
            const { winner, roomId } = data;
            const room = rooms.get(roomId);
            if (room) {
                const winningPlayer = room.players.find(p => p.id === winner);
                if (winningPlayer) {
                    await Player.updateScore(
                        winningPlayer.dbId,
                        winningPlayer.score,
                        true
                    );
                }

                // Mettre à jour les scores des autres joueurs
                for (const player of room.players) {
                    if (player.id !== winner) {
                        await Player.updateScore(
                            player.dbId,
                            player.score,
                            false
                        );
                    }
                }
            }
        } catch (error) {
            console.error('Error updating scores:', error);
        }
    });

    socket.on('select-word', (data) => {
        const room = rooms.get(data.roomId);
        if (room && room.currentDrawer?.id === socket.id) {
            room.selectWord(data.word);
        }
    });

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

const PORT = process.env.PORT || 3000;
http.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
